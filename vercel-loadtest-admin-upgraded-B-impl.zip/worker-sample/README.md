Worker sample updated: verifies job JWT signatures and posts telemetry signed with HMAC-SHA512.
Make sure to set NODE_SECRET and ORCHESTRATION_URL environment variables.
