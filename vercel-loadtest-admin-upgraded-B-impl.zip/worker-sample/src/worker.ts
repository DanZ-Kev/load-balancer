const ORCH = Deno.env.get('ORCHESTRATION_URL') || 'http://localhost:3000/api/jobs/poll'
const NODE_ID = Deno.env.get('NODE_ID') || 'node-1'
const NODE_SECRET = Deno.env.get('NODE_SECRET') || 'CHANGE_ME'
import {createHmac} from 'https://deno.land/std@0.201.0/hash/mod.ts' // placeholder

async function poll(){
  const res = await fetch(ORCH, {
    method:'POST',
    headers:{'content-type':'application/json'},
    body: JSON.stringify({ nodeId: NODE_ID, secret: NODE_SECRET })
  })
  if(!res.ok) return null
  const job = await res.json()
  return job
}

async function postTelemetry(jobId, payload){
  const body = JSON.stringify({ jobId, nodeId: NODE_ID, payload })
  const ts = Math.floor(Date.now()/1000).toString()
  // HMAC-SHA512 equivalent in Deno standard lib; for demo we use a simple fetch
  await fetch((Deno.env.get('ORCHESTRATION_URL') || '') + '/telemetry/ingest', {
    method:'POST', headers:{ 'content-type':'application/json', 'x-timestamp': ts, 'x-signature': 'PLACEHOLDER' }, body
  })
}

async function run(){
  for(;;){
    const job = await poll()
    if(job){
      console.log('Job', job.id, 'received; verifying signature...')
      // Verify JWT signature (workers should validate with public key)
      // For demo we skip verification; production must verify
      // Download script via signed URL and run in restricted deno subprocess (no-net by default)
      console.log('Simulating execution...')
      await postTelemetry(job.id, { status:'completed', out:'ok' })
    }
    await new Promise(r=>setTimeout(r, 4000))
  }
}
run()
