
import React from 'react';
import { Button } from '@/components/ui/button';

export default {
  title: 'Example/Button',
  component: Button,
};

export const Primary = () => <Button variant="default">Primary Button</Button>;
export const Danger = () => <Button variant="destructive">Danger Button</Button>;
