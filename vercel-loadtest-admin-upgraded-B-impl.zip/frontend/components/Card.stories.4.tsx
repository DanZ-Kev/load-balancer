import React from 'react';
import Card from './ui/Card';

export default { title: 'Card/Example4' };

export const Basic = () => <Card><div style={padding:20}>Example Card 4</div></Card>;
Basic.storyName = 'Basic Card 4';
