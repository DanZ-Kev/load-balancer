import React from 'react';

export default { title: 'PolicyBuilder' };

export const Example = () => <div style={{padding:20}}><h3>Policy Builder (UI preview)</h3><pre>{JSON.stringify({rule:'allow_test_targets', maxConcurrency:10}, null, 2)}</pre></div>;
