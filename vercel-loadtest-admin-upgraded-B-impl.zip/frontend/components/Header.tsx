'use client'
import React from 'react'
import Link from 'next/link'
export default function Header(){
  return (
    <header className='w-full flex items-center justify-between p-4 shadow-sm bg-white dark:bg-gray-900'>
      <div className='flex items-center gap-3'>
        <Link href='/' className='font-bold text-lg'>LoadAdmin+</Link>
        <span className='text-xs text-gray-500'>Secure orchestration</span>
      </div>
      <nav aria-label='Main navigation'>
        <ul className='flex gap-3 items-center'>
          <li><Link href='/nodes' className='px-3 py-1 rounded'>Nodes</Link></li>
          <li><Link href='/scripts' className='px-3 py-1 rounded'>Scripts</Link></li>
          <li><Link href='/settings' className='px-3 py-1 rounded'>Settings</Link></li>
        </ul>
      </nav>
    </header>
  )
}
