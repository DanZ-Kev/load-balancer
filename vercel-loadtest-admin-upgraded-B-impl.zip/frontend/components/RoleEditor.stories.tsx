import React from 'react';
import RoleEditor from './RoleEditor';

export default { title: 'RoleEditor' };

export const Default = () => <RoleEditor initial={['nodes.create','jobs.create']} onSave={(p)=>console.log('save',p)} />;
