'use client'
import React, { useState } from 'react'
import Card from './ui/Card'

const PERMS = [
  'nodes.create','nodes.approve','jobs.create','jobs.approve','targets.whitelist.add','settings.theme.edit'
]

export default function RoleEditor({initial=['nodes.create'] , onSave=(p: string[])=>{} }:{initial?:string[], onSave?: (p:string[])=>void}){
  const [checked, setChecked] = useState<Record<string,boolean>>(()=> Object.fromEntries(PERMS.map(p=>[p, initial.includes(p)])))
  function toggle(k:string){ setChecked(prev=>({...prev,[k]:!prev[k]})) }
  return (
    <Card>
      <h3 className='font-semibold'>Role Editor</h3>
      <div className='mt-3 grid grid-cols-1 md:grid-cols-2 gap-2'>
        {PERMS.map(p=>(
          <label key={p} className='flex items-center gap-2'>
            <input type='checkbox' checked={!!checked[p]} onChange={()=>toggle(p)} />
            <span className='text-sm'>{p}</span>
          </label>
        ))}
      </div>
      <div className='mt-3'><button className='px-3 py-2 bg-primary text-white rounded' onClick={()=>onSave(Object.keys(checked).filter(k=>checked[k]))}>Save</button></div>
    </Card>
  )
}
