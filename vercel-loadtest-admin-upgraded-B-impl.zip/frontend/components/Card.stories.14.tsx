import React from 'react';
import Card from './ui/Card';

export default { title: 'Card/Example14' };

export const Basic = () => <Card><div style={padding:20}>Example Card 14</div></Card>;
Basic.storyName = 'Basic Card 14';
