import React from 'react'
import Card from '../components/ui/Card'

export default function Dashboard(){
  return (
    <section>
      <h1 className='text-2xl font-bold'>Upgraded Dashboard</h1>
      <div className='mt-4 grid grid-cols-1 md:grid-cols-3 gap-4'>
        <Card><strong>Nodes</strong><div className='text-sm text-gray-500'>5 registered</div></Card>
        <Card><strong>Active Jobs</strong><div className='text-sm text-gray-500'>2 running</div></Card>
        <Card><strong>Errors</strong><div className='text-sm text-gray-500'>0</div></Card>
      </div>
    </section>
  )
}
